export default interface Tweet {
    id: string,
    fullName: string,
    twitterHandle: string,
    tweetDesc: string,
    date: string,
    image: string,
    belongs: string
}