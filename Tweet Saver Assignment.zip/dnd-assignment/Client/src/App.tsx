import React, { Component } from 'react';
import './App.css'
import TweetSaverComponent from './components/tweet-saver-component';

export class App extends Component {
  render() {
    return (
      <div className="container-drag">
          <TweetSaverComponent></TweetSaverComponent>
      </div>
    )
  }
}

export default App