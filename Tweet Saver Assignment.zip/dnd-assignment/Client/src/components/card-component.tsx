import React from 'react'

function Card(props: any) { // should avoid any type
    let { tweet, parentCallback } = props;
    return (
        <div draggable 
            onDragStart={(e) => parentCallback(e, tweet.id )}
            className="draggable">
            <div id="card">
                <p>{tweet.fullName}  @{tweet.twitterHandle}</p>
                <p className="tweet-description">{tweet.tweetDesc}</p>
            </div></div>
    )
}

export default Card
