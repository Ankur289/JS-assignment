import React, { Component } from 'react';
import Axios from 'axios';
import SearchComponent from './search-component';
import Tweet from '../tweet-model';
import Card from './card-component';

class TweetSaverComponent extends Component {
    state = {
        savedTweets: Array<Tweet>(),
        allTweets: Array<Tweet>(),
    }

    hydrateStateWithLocalStorage() {
        // for all items in state
        for (let key in this.state) {
            if (localStorage.hasOwnProperty(key)) {
                let value = localStorage.getItem(key) || "";

                // parse the localStorage string and setState
                try {
                    const savedTweet: Array<Tweet> = JSON.parse(value);
                    this.setState(() =>
                        ({
                            savedTweets: savedTweet,
                            //below logic should be improved later
                            allTweets: this.state.allTweets.filter((tweet) => {
                                // Updating the savedTweets in the all tweets server response for segregating at render
                                savedTweet.map((tw) => {
                                    if (tweet.id === tw.id) {
                                        tweet.belongs = "saved";
                                    }
                                    return tweet;
                                })
                                return tweet;
                            })
                        }))
                } catch (e) {
                    // handle empty string
                    this.setState({ [key]: value });
                }
            }
        }
    }

    saveStateToLocalStorage() {
        // save to localStorage
        localStorage.setItem("savedTweets", JSON.stringify(this.state.savedTweets));
    }

    getTweets = (query?: string) => {
        const param = query || "obama";
        const url = `http://localhost:3001/tweets/${param}` // Should have a centralized service to handle all data calls 
        Axios.get(url).then(
            (result) => {
                this.setState({
                    isLoaded: true,
                    allTweets: result.data
                });

                this.hydrateStateWithLocalStorage();
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
                this.setState({
                    isLoaded: true,
                    error
                });
            }
        ).catch(error => {
            console.log(error)
        })
    }

    componentDidMount() {
        // add event listener to save state to localStorage
        // when user leaves/refreshes the page
        window.addEventListener(
            "beforeunload",
            this.saveStateToLocalStorage.bind(this)
        );
        this.getTweets();
    }

    componentWillUnmount() {
        window.removeEventListener(
            "beforeunload",
            this.saveStateToLocalStorage.bind(this)
        );

        // saves if component has a chance to unmount
        this.saveStateToLocalStorage();
    }

    onDragOver = (event: any) => {
        event.preventDefault();
    }

    onDragStart = (event: any, id: string) => {
        event.dataTransfer.setData("id", id)
    }

    onDrop = (event: any, belongs: string) => {
        const tweetId = event.dataTransfer.getData("id");
        let savedTw = [...this.state.savedTweets];
        const tweets = this.state.allTweets.filter((tweet) => {
            if (tweet.id === tweetId) {
                tweet.belongs = belongs;
            }
            return tweet.belongs.toLowerCase() === "saved";
        });
        // should create a array without dupes
        savedTw = [...new Set([...savedTw, ...tweets])];
        this.setState((prevState) => ({ ...prevState, savedTweets: savedTw }))
    }

    searchFilterValue = (searchText: string) => {
        this.getTweets(searchText);
    }

    render() {
        let tweets = {
            all: Array<{}>(),
            saved: Array<{}>()
        }
        // should create a array without dupes
        let allTweets = [...new Set([...this.state.allTweets, ...this.state.savedTweets])];
        allTweets = allTweets.filter((item, index) => allTweets.indexOf(item) === index);
        allTweets && allTweets.forEach((tweet) => {
            // Todo - Logic to be improved
            if (tweet && tweet.belongs.toLowerCase() === "all") {
                tweets.all.push(<Card key={tweet.id} tweet={tweet} parentCallback={this.onDragStart}></Card>);
            } else if (tweet && tweet.belongs.toLowerCase() === "saved") {
                tweets.saved.push(<Card key={tweet.id} tweet={tweet} parentCallback={this.onDragStart}></Card>)
            }
        });

        return (
            <React.Fragment>
                <h2 className="header">Tweet Saver</h2>
                
                <div className="tweets" >
                    <p>Drag and drop to save tweets. 
                        It will be persisted across browser tab or refresh.</p>
                    <SearchComponent parentCallback={this.searchFilterValue}></SearchComponent>
                    {tweets.all}
                </div>
                <div className="droppable"
                    onDragOver={(e) => this.onDragOver(e)}
                    onDrop={(e) => this.onDrop(e, 'saved')}>
                    <span className="task-header">Saved Tweets</span>
                    {tweets.saved}
                </div>
            </React.Fragment>
        )
    }
}

export default TweetSaverComponent