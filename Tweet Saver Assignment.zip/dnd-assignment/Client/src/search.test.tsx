import React from 'react';
import { render, fireEvent} from '@testing-library/react'; 
import '@testing-library/jest-dom/extend-expect';
import SearchComponent from './components/search-component';

it("renders search component", () => {
    const handleChange = jest.fn();
    const {queryByPlaceholderText, queryByTestId} = render(<SearchComponent parentCallback={handleChange}/>);
    const searchInput : any = queryByPlaceholderText('Search Twitter');
    fireEvent.change(searchInput, {target: {value: "test"}});
    expect((searchInput as HTMLInputElement).value).toBe("test");
    const searchClick : any = queryByTestId("test-submitparent");
    fireEvent.click(searchClick);
    expect(handleChange).toHaveBeenCalled();
});