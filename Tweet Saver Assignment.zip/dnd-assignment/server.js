const express = require('express');
const request = require('request');

const app = express();

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
});

const formatData = (data) => {
  const tweets = [];
  data.tweets.map((tw) => {
    let tweet = {
      id: tw.idStr,
      twitterHandle: tw.user.screenName,
      fullName: tw.user.name,
      tweetDesc: tw.text,
      image: tw.user.profileImageUrlHttps,
      date: tw.createdAt,
      belongs: "all"
    };

    tweets.push(tweet)
  })
  return tweets;
}

app.get('/tweets/:query', (req, res) => {
  const query = req.params.query;
  request(
    { url: 'http://tweetsaver.herokuapp.com/?q=' + query + '&count=10' }, // template literal not working #cleanup
    (error, response, body) => {
      if (error || response.statusCode !== 200) {
        return res.status(500).json({ type: 'error', message: err.message });
      }

      const formattedData = formatData(JSON.parse(body));
      res.json(formattedData);
    }
  )
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`listening on ${PORT}`));