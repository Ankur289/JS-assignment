import * as React from 'react';
import search from '../assets/Search_Icon.svg';

export const SearchComponent = ({ parentCallback }: { parentCallback: any }) => {
    const [searchValue, setSearchValue] = React.useState({ input: '' });

    const OnHandleChange = (event: { target: { value: string; }; }) => {
        const searchText = event.target.value;
        setSearchValue({ input: searchText });
    }

    const onHandleSearchClick = () => {
        parentCallback(searchValue.input);
    }

    const handleSearchBoxKeyPress = (event: any) => {
        var code = event.keyCode || event.which;
        if (code === 13) {
            parentCallback(searchValue.input);
        }
    }

    return (
        <div>
            <input className="searchBox" id="inputSearchBox" aria-label="Search Twitter" type="textbox"
                placeholder="Search Twitter" onChange={OnHandleChange} onKeyPress={handleSearchBoxKeyPress} />
            <span><input  data-testid="azs-test-search-button" type="image" alt="search" src={search} className="search" onClick={onHandleSearchClick} /></span>
        </div>
    );
}

export default SearchComponent;